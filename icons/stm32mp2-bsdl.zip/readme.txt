************************************************************************************
* @file    readme.txt                                                              *
* @author  MCD Application Team                                                    *
* @version V2.0                                                                    *
* @date    10-February-2025                                                        *               *
* @brief   Boundary Scan Description Language(BSDL) files for the STM32MP2 MCUs.   *                     
************************************************************************************
* COPYRIGHT(c) 2025 STMicroelectronics                                             * 
*                                                                                  *
* Redistribution and use in source and binary forms, with or without modification, *
* are permitted provided that the following conditions are met:                    *
*   1. Redistributions of source code must retain the above copyright notice,      *
*      this list of conditions and the following disclaimer.                       *
*   2. Redistributions in binary form must reproduce the above copyright notice,   *
*      this list of conditions and the following disclaimer in the documentation   *
*      and/or other materials provided with the distribution.                      *
*   3. Neither the name of STMicroelectronics nor the names of its contributors    *
*      may be used to endorse or promote products derived from this software       *
*      without specific prior written permission.                                  *
*                                                                                  *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"      *
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE        *
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE   *
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE     *
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL       *
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR       *
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER       *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,    *
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE    *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.             *
************************************************************************************

=======================
How to use BSDL Files :
=======================

The STM32MP2 MCUs integrate two serially connected JTAG TAPs, the boundary scan
TAP (IR is 5-bit wide) and the CortexMx TAP (IR is 4-bit wide).

The package contains :

   + A BSDL File for the CortexMx TAP and is common to all STM32MP2 devices.

   + Boundary scan BSDL Files for each STM32MP251_253_255_257 device on different packages :

	  o TFBGA436
	  o VFBGA424
	  o VFBGA361
        o TFBGA361
	  
+ Boundary scan BSDL Files for each STM32MP231_233_235 device on different packages :

	  o VFBGA424
	  o VFBGA361
        o TFBGA361
	  

In order to run boundary scan, always provide two BSDL files to your JTAG Boundary scan tool:
the "CortexMx.bsd" and your selected "STM32WBxx_device_Package.bsd".  

WARNING : Do not combine both BSDL files in a single TAP with 9-bit wide !

For more details on the internal TAPs description refer to the Reference Manual
of the selected STM32xxxx device , Section : JTAG TAP connection.

========================
* V2.0 - 10-February-2025  
========================

  + Added BSDL files for STM32MP231_233_235 devices.
  + Added the TFBGA361 package for the STM32MP251_253_255_257.
========================
* V1.0 - 21-June-2024   
========================

  + Created with BSDL files for STM32MP251_253_255_257 devices.
Comment: For the VFBGA424 package, the pin identifiers for VDD, VDDA18PPL3, VDDCORE, VDDCPU, VDDGPU, VDDQDDR, and VSS 
that originally start with the number 1 have been changed to start with the letter I to ensure compatibility 
with the BSDLCheker tool, as retaining the number 1 leads to an error.
 

******************* (C) COPYRIGHT 2025  STMicroelectronics *****END OF FILE
